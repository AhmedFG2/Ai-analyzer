const express = require('express');
const https = require('https');
const fs = require('fs');
const app = express();

// Security and CORS headers middleware
app.use((req, res, next) => {
  // Cross-Origin isolation headers
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
  
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  
  // HLS MIME types
  if (req.url.endsWith('.m3u8')) {
    res.setHeader('Content-Type', 'application/vnd.apple.mpegurl');
  } else if (req.url.endsWith('.ts')) {
    res.setHeader('Content-Type', 'video/MP2T');
  }
  
  next();
});

// Serve static files from HLS output directory
app.use(express.static('C:<PATH>\\hls_output\\hls'));

// HTTPS configuration
const options = {
  key: fs.readFileSync('C:<PATH>\\key.pem'), #your ssl key
  cert: fs.readFileSync('C:<PATH>\\cert.pem'), #your ssl certificate 
};

// Start HTTPS server
https.createServer(options, app).listen(443, () => {
  console.log('Secure HLS server running on port 443');
  console.log('Stream URL: https://localhost/stream.m3u8');
});